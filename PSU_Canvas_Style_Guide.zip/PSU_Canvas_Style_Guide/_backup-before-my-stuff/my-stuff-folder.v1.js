(function () {
  const store = window.CCBEMyStuff;
  const $ = (id) => document.getElementById(id);
  const statusBox = $('folderStatusBox');
  const statusText = $('folderStatusText');
  const message = $('folderMessage');
  const chooseButton = $('chooseFolderButton');
  const grantButton = $('grantButton');
  const syncButton = $('syncButton');
  const importButton = $('importButton');
  const disconnectButton = $('disconnectButton');

  function say(text, isError) {
    message.textContent = text;
    message.classList.toggle('is-error', Boolean(isError));
  }

  function syncSummary(result) {
    if (!result.ok && !result.written && !result.deleted) return 'Could not write to the folder.';
    const parts = [];
    parts.push(`${result.written} file(s) written`);
    parts.push(`${result.deleted} file(s) removed`);
    return `Sync complete: ${parts.join(', ')}.${result.ok ? '' : ' Some changes failed; try Sync now again.'}`;
  }

  async function render() {
    const state = await store.getFolderState();
    const [items, waiting] = await Promise.all([store.getItems(), store.countUnsynced()]);
    statusBox.dataset.state = state.status;
    const connected = state.status === 'granted' || state.status === 'prompt' || state.status === 'denied';

    chooseButton.hidden = state.status === 'unsupported';
    chooseButton.textContent = connected ? 'Choose a different folder…' : 'Choose folder…';
    chooseButton.className = connected ? 'options-copy-button' : 'layout-insert-button';
    grantButton.hidden = !(state.status === 'prompt' || state.status === 'denied');
    syncButton.hidden = state.status !== 'granted';
    importButton.hidden = !connected;
    disconnectButton.hidden = !connected;

    if (state.status === 'unsupported') {
      statusText.textContent = 'This browser does not support saving to a folder. Your items are still saved in your Chrome profile.';
    } else if (state.status === 'none') {
      statusText.textContent = `No folder connected. ${items.length} item(s) saved in your Chrome profile.`;
    } else if (state.status === 'granted') {
      statusText.textContent = `Connected to “${state.name}”. ${items.length} item(s)${waiting ? `, ${waiting} change(s) waiting to sync` : ', all synced'}.`;
    } else {
      statusText.textContent = `Connected to “${state.name}”, but Chrome needs your permission again. ${waiting} change(s) waiting to sync.`;
    }
  }

  async function run(button, task) {
    button.disabled = true;
    try {
      await task();
    } catch (error) {
      if (error && error.name === 'AbortError') say('No folder chosen.');
      else say(`Something went wrong: ${error && error.message ? error.message : error}`, true);
    } finally {
      button.disabled = false;
      render();
    }
  }

  chooseButton.addEventListener('click', () => run(chooseButton, async () => {
    const result = await store.pickFolder();
    say(`Folder connected. ${syncSummary(result)}`);
  }));

  grantButton.addEventListener('click', () => run(grantButton, async () => {
    const result = await store.syncAll({ request: true });
    const state = await store.getFolderState();
    say(state.status === 'granted' ? syncSummary(result) : 'Permission was not granted.', state.status !== 'granted');
  }));

  syncButton.addEventListener('click', () => run(syncButton, async () => {
    say(syncSummary(await store.syncAll({ request: true })));
  }));

  importButton.addEventListener('click', () => run(importButton, async () => {
    const count = await store.importFromFolder();
    say(count ? `Imported ${count} item(s) into My Stuff.` : 'No new .html files found in the folder.');
  }));

  disconnectButton.addEventListener('click', () => run(disconnectButton, async () => {
    await store.disconnectFolder();
    say('Folder disconnected. Files already in the folder were left alone.');
  }));

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local') render();
  });

  render();
})();
