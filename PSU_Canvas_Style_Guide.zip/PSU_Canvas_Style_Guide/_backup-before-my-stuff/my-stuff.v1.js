// ---------------------------------------------------------------------------
// My Stuff panel (popup). Depends on my-stuff-store.js and popup.js globals:
// setStatus, pasteCustomHtml, wrapContentInsertSpacing.
// ---------------------------------------------------------------------------
(function () {
  const store = window.CCBEMyStuff;
  if (!store) return;

  const $ = (id) => document.getElementById(id);
  const mainView = $('myStuffMainView');
  const addView = $('myStuffAddView');
  const detailView = $('myStuffDetailView');
  const grid = $('myStuffGrid');
  const emptyState = $('myStuffEmpty');
  const searchInput = $('myStuffSearch');
  const typeFilter = $('myStuffTypeFilter');
  const folderText = $('myStuffFolderText');
  const folderButton = $('myStuffFolderButton');
  const form = $('myStuffForm');
  const typeInput = $('myStuffType');
  const titleInput = $('myStuffTitle');
  const descInput = $('myStuffDesc');
  const htmlInput = $('myStuffHtml');
  const formError = $('myStuffFormError');
  const formPreview = $('myStuffFormPreview');
  const saveButton = $('myStuffSaveButton');
  const detailTitle = $('myStuffDetailTitle');
  const detailDesc = $('myStuffDetailDesc');
  const detailMeta = $('myStuffDetailMeta');
  const detailPreview = $('myStuffDetailPreview');
  const insertButton = $('myStuffInsertButton');
  const copyButton = $('myStuffCopyButton');
  const removeButton = $('myStuffRemoveButton');

  const THUMB_RENDER_WIDTH = 900;
  let items = [];
  let selectedId = null;
  let removeArmed = false;
  let previewTimer = null;

  const notify = (message, isError) => {
    if (typeof setStatus === 'function') setStatus(message, isError);
  };

  // ---- Views -------------------------------------------------------------
  function showView(name) {
    mainView.hidden = name !== 'main';
    addView.hidden = name !== 'add';
    detailView.hidden = name !== 'detail';
    window.scrollTo({ top: 0 });
  }

  function openFolderPage() {
    chrome.tabs.create({ url: chrome.runtime.getURL('my-stuff-folder.html') });
  }

  // ---- Preview helpers ---------------------------------------------------
  function previewDoc(html) {
    return `<!doctype html><html><head><meta charset="utf-8"></head><body style="margin:10px; font-family:'Lato', Arial, Helvetica, sans-serif; color:#2d3b45;">${html}</body></html>`;
  }

  // Thumbnails render into a shadow root so the saved HTML's styles stay
  // contained. Scripts never run (innerHTML + extension CSP), and embeds are
  // swapped for placeholders so cards stay fast.
  function sanitizeForThumb(html) {
    const template = document.createElement('template');
    template.innerHTML = html;
    template.content.querySelectorAll('script, noscript, link, meta, base').forEach((el) => el.remove());
    template.content.querySelectorAll('iframe, video, audio, object, embed').forEach((el) => {
      const box = document.createElement('div');
      box.style.cssText = 'background:#1e407c;opacity:.85;border-radius:8px;height:320px;width:100%;';
      el.replaceWith(box);
    });
    template.content.querySelectorAll('*').forEach((el) => {
      Array.from(el.attributes).forEach((attr) => {
        if (/^on/i.test(attr.name)) el.removeAttribute(attr.name);
      });
    });
    return template.innerHTML;
  }

  function makeThumb(item) {
    const thumb = document.createElement('span');
    thumb.className = 'preview ms-thumb';
    thumb.setAttribute('aria-hidden', 'true');
    const host = document.createElement('span');
    host.className = 'ms-thumb-host';
    const root = host.attachShadow({ mode: 'open' });
    root.innerHTML = `<style>:host{all:initial;display:block;}.page{width:${THUMB_RENDER_WIDTH}px;padding:16px;box-sizing:border-box;font-family:'Lato',Arial,Helvetica,sans-serif;color:#2d3b45;background:#fff;transform-origin:0 0;pointer-events:none;}img{max-width:100%;}</style><div class="page">${sanitizeForThumb(item.html)}</div>`;
    thumb.appendChild(host);
    const badge = document.createElement('span');
    badge.className = `ms-type-badge ms-type-${item.type}`;
    badge.textContent = store.TYPES[item.type] || 'Element';
    thumb.appendChild(badge);
    return thumb;
  }

  function scaleThumbs() {
    grid.querySelectorAll('.ms-thumb').forEach((thumb) => {
      const page = thumb.querySelector('.ms-thumb-host').shadowRoot.querySelector('.page');
      const width = thumb.clientWidth || 190;
      page.style.transform = `scale(${width / THUMB_RENDER_WIDTH})`;
    });
  }

  // ---- Grid --------------------------------------------------------------
  function renderGrid() {
    grid.innerHTML = '';
    const query = String(searchInput.value || '').toLowerCase().trim();
    const type = typeFilter.value;
    const visible = items.filter((item) => {
      const matchesType = type === 'all' || item.type === type;
      const text = `${item.title} ${item.desc} ${item.type}`.toLowerCase();
      return matchesType && (!query || text.includes(query));
    });

    emptyState.hidden = items.length !== 0;
    grid.hidden = items.length === 0;

    visible.forEach((item) => {
      const card = document.createElement('button');
      card.type = 'button';
      card.className = 'layout-card ms-card';
      card.dataset.myStuffId = item.id;
      card.appendChild(makeThumb(item));
      const title = document.createElement('strong');
      title.textContent = item.title;
      const desc = document.createElement('small');
      desc.textContent = item.desc || 'No description';
      card.appendChild(title);
      card.appendChild(desc);
      card.addEventListener('click', () => openDetail(item.id));
      grid.appendChild(card);
    });

    if (items.length && !visible.length) {
      const none = document.createElement('div');
      none.className = 'no-results';
      none.textContent = 'No matching items found.';
      grid.appendChild(none);
    }

    requestAnimationFrame(scaleThumbs);
  }

  async function refresh() {
    items = await store.getItems();
    renderGrid();
    renderFolderStatus();
    if (selectedId && !items.some((item) => item.id === selectedId) && !detailView.hidden) {
      selectedId = null;
      showView('main');
    }
  }

  async function renderFolderStatus() {
    const state = await store.getFolderState();
    const waiting = await store.countUnsynced();
    folderButton.hidden = false;
    folderText.parentElement.dataset.state = state.status;

    if (state.status === 'unsupported') {
      folderText.textContent = 'Saved privately in your Chrome profile. (This browser can\'t save to a folder.)';
      folderButton.hidden = true;
    } else if (state.status === 'none') {
      folderText.textContent = 'Saved privately in your Chrome profile. Connect a folder to also keep each item as an .html file.';
      folderButton.textContent = 'Connect folder';
    } else if (state.status === 'granted') {
      folderText.textContent = waiting
        ? `Saving to “${state.name}” — ${waiting} change(s) waiting to sync.`
        : `Saved in your Chrome profile and in “${state.name}”.`;
      folderButton.textContent = 'Folder settings';
    } else {
      folderText.textContent = `“${state.name}” needs permission again${waiting ? ` — ${waiting} change(s) waiting to sync` : ''}.`;
      folderButton.textContent = 'Reconnect';
    }
  }

  // ---- Add form ----------------------------------------------------------
  function openAddForm() {
    form.reset();
    formError.hidden = true;
    formPreview.srcdoc = previewDoc('<p style="color:#5f6f7a;">Paste HTML to see a preview.</p>');
    showView('add');
    titleInput.focus();
  }

  function schedulePreview() {
    clearTimeout(previewTimer);
    previewTimer = setTimeout(() => {
      const html = htmlInput.value.trim();
      formPreview.srcdoc = previewDoc(html || '<p style="color:#5f6f7a;">Paste HTML to see a preview.</p>');
    }, 200);
  }

  function showFormError(message) {
    formError.textContent = message;
    formError.hidden = false;
  }

  async function handleSave(event) {
    event.preventDefault();
    formError.hidden = true;
    const title = titleInput.value.trim();
    const html = htmlInput.value.trim();
    if (!title) { showFormError('Add a title.'); titleInput.focus(); return; }
    if (!html) { showFormError('Paste the HTML you want to save.'); htmlInput.focus(); return; }
    if (items.some((item) => item.title.toLowerCase() === title.toLowerCase() && item.type === typeInput.value)) {
      showFormError(`You already have a ${typeInput.value} called “${title}”. Use a different title.`);
      titleInput.focus();
      return;
    }

    saveButton.disabled = true;
    try {
      const { item, savedToFolder } = await store.addItem({
        type: typeInput.value,
        title,
        desc: descInput.value,
        html
      });
      await refresh();
      showView('main');
      notify(savedToFolder
        ? `“${item.title}” saved to My Stuff and to ${item.fileName}.`
        : `“${item.title}” saved to My Stuff.`, false);
    } catch (error) {
      showFormError(`Could not save: ${error && error.message ? error.message : error}`);
    } finally {
      saveButton.disabled = false;
    }
  }

  // ---- Detail view -------------------------------------------------------
  function resetRemoveButton() {
    removeArmed = false;
    removeButton.textContent = 'Remove';
    removeButton.classList.remove('is-armed');
  }

  function openDetail(id) {
    const item = items.find((entry) => entry.id === id);
    if (!item) return;
    selectedId = id;
    resetRemoveButton();
    detailTitle.textContent = item.title;
    detailDesc.textContent = item.desc || 'No description.';
    detailMeta.textContent = `${store.TYPES[item.type] || 'Element'} · ${item.fileName}`;
    detailPreview.srcdoc = previewDoc(item.html);
    insertButton.textContent = item.type === 'page' ? 'Insert Page' : 'Insert Element';
    showView('detail');
  }

  function selectedItem() {
    return items.find((entry) => entry.id === selectedId);
  }

  async function handleInsert() {
    const item = selectedItem();
    if (!item) return;
    const html = typeof wrapContentInsertSpacing === 'function' ? wrapContentInsertSpacing(item.html) : item.html;
    await pasteCustomHtml(html, `${item.title} pasted into the Canvas editor.`);
  }

  async function handleCopy() {
    const item = selectedItem();
    if (!item) return;
    await navigator.clipboard.writeText(item.html);
    notify(`${item.title} HTML copied to the clipboard.`, false);
  }

  async function handleRemove() {
    const item = selectedItem();
    if (!item) return;
    if (!removeArmed) {
      removeArmed = true;
      removeButton.textContent = 'Click again to remove';
      removeButton.classList.add('is-armed');
      setTimeout(() => { if (removeArmed) resetRemoveButton(); }, 4000);
      return;
    }
    removeButton.disabled = true;
    try {
      const result = await store.removeItem(item.id);
      selectedId = null;
      await refresh();
      showView('main');
      const state = await store.getFolderState();
      let message = `“${item.title}” removed from My Stuff.`;
      if (state.status === 'granted' && result.removedFromFolder) message = `“${item.title}” removed from My Stuff and the ${store.FOLDER_NAME} folder.`;
      else if (state.handle) message += ' The file will be deleted from your folder the next time it syncs.';
      notify(message, false);
    } catch (error) {
      notify(`Could not remove: ${error && error.message ? error.message : error}`, true);
    } finally {
      removeButton.disabled = false;
      resetRemoveButton();
    }
  }

  // ---- Wire up -----------------------------------------------------------
  $('myStuffAddButton').addEventListener('click', openAddForm);
  $('myStuffEmptyAddButton').addEventListener('click', openAddForm);
  $('myStuffAddBack').addEventListener('click', () => showView('main'));
  $('myStuffCancelButton').addEventListener('click', () => showView('main'));
  $('myStuffDetailBack').addEventListener('click', () => showView('main'));
  folderButton.addEventListener('click', openFolderPage);
  form.addEventListener('submit', handleSave);
  htmlInput.addEventListener('input', schedulePreview);
  searchInput.addEventListener('input', renderGrid);
  typeFilter.addEventListener('change', renderGrid);
  insertButton.addEventListener('click', handleInsert);
  copyButton.addEventListener('click', handleCopy);
  removeButton.addEventListener('click', handleRemove);
  document.querySelectorAll('.panel-tab[data-panel]').forEach((tab) => {
    tab.addEventListener('click', () => requestAnimationFrame(scaleThumbs));
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes[store.ITEMS_KEY] || changes[store.PENDING_DELETES_KEY]) refresh();
  });

  // Quietly catch up on any pending folder writes/deletes when the popup opens.
  store.syncAll().catch(() => {}).finally(refresh);
})();
